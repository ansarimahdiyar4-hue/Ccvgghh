# Bepar VPN 2.0 — پورت اندروید (نسخهٔ نهایی ساختاری)

پروژهٔ کامل Android Studio (Kotlin + Jetpack Compose) برای بازسازی Bepar VPN روی اندروید.

این نسخه شامل:
- رابط کاربری کامل و وفادار به دسکتاپ (خانه، سرورها، تنظیمات)
- سرویس واقعی `VpnService` یکپارچه با **sing-box (libbox)**
- لایهٔ بک‌اند بومی (SourceRepository، Config Generator، Security، GeoIP)
- دارایی‌های استخراج‌شده (فونت Estedad/Inter، لوگو، ۲۵۷ پرچم SVG)
- هستهٔ native sing-box (libbox.aar v1.14.0) داخل بسته
- ورک‌فلو GitHub Actions (اختیاری برای بیلد ابری)

---

## وضعیت فعلی (صادقانه)

| جزء | وضعیت |
|-----|--------|
| UI + انیمیشن + RTL + تم | کامل |
| VpnService + Manifest | کامل |
| SourceRepository + کش رمزنگاری‌شده | کامل |
| تولید کانفیگ Sing-box / Xray | کامل |
| امنیت (Keystore AES-GCM) | کامل |
| **هستهٔ native `libbox.aar`** | **شامل شده (v1.14.0)** |
| منبع کانفیگ پیش‌فرض | فید عمومی morpheus (زنده) |

`app/libs/libbox.aar` داخل بسته است. پس از بیلد و نصب APK و دادن مجوز VPN سیستم، اتصال واقعی باید برقرار شود.

---

## ساخت APK

```bash
# در Android Studio باز کنید یا:
./gradlew assembleDebug
# خروجی: app/build/outputs/apk/debug/app-debug.apk
```

نیازمندی‌ها: JDK 17، Android SDK (compileSdk 35).

هسته از قبل داخل `app/libs/libbox.aar` است؛ نیازی به ساخت جداگانه نیست.

---

## ساختار مهم

```
app/src/main/java/com/bepar/vpn/
├── MainActivity.kt
├── vpn/BeparVpnService.kt          ← VpnService واقعی + libbox
├── backend/
│   ├── SourceRepository.kt         ← fetch + کش رمزنگاری‌شده
│   ├── SingBoxConfigGenerator.kt
│   ├── XrayConfigGenerator.kt
│   ├── ConfigUriParser.kt
│   ├── GeoIpRepository.kt
│   ├── ServerTester.kt
│   └── SecurityGuard.kt
├── security/
│   ├── BeparKeystoreCrypto.kt
│   └── BeparSettingsStore.kt
├── state/BeparViewModel.kt
├── ui/screens/ ...
└── i18n/BeparStrings.kt
```

---

## مجوز و حقوق

- کد و دارایی‌های استخراج‌شده از Bepar VPN متعلق به صاحب اثر اصلی است (Ada Wong).
- هستهٔ sing-box تحت مجوز خودش (GPL-compatible / طبق مخزن SagerNet) است.
- فونت‌ها: SIL Open Font License 1.1 (متن NOTICE را حفظ کنید).
- فقط برای استفادهٔ شخصی/تحقیقاتی در چارچوب حقوق صاحب اثر استفاده کنید.

مستندات عمیق‌تر: پوشهٔ `docs/` (PORT-STATUS، FEATURE-INVENTORY، contracts، backend-analysis).
