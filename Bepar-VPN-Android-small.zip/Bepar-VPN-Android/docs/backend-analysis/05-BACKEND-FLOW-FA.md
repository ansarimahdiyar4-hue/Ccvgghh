# تحلیل عمیق جریان Backend

> در این سند «دیده شده» به معنی رشته/endpoint/قرارداد UI است؛ ترتیب اجرای جزئیات تا وقتی سورس Rust یا trace زنده نباشد، در بخش‌هایی استنباطی است.

## 1. Boot و initialization

1. رابط با فرمان `win_show` پنجره را نمایان می‌کند؛ در پیام باینری یک startup fallback نیز دیده می‌شود.
2. `get_initial` تنظیمات، نسخه، source registry، cache/server list و status را به UI می‌دهد.
3. `startup_check` به‌صورت موازی امنیت و شرایط استفاده را preflight می‌کند.
4. اگر setup کامل نشده باشد، مسیر UI زبان → پذیرش Terms → انتخاب source/mode اجرا می‌شود.
5. در onboarding، `save_settings` ابتدا source/mode را ذخیره می‌کند، سپس فقط همان source را fetch می‌کند؛ `onboarded=true` تنها پس از دریافت فهرست غیرخالی ذخیره می‌شود.
6. هنگام launch، backend refresh pipeline را نیز می‌تواند خودش آغاز کند؛ frontend از eventها وضعیت progress را می‌گیرد.

## 2. Source/feed fetch و caching

شواهد مستقیم در binary:
- 7 منبع انتخاب‌پذیر؛ `ss44` پیش‌فرض و `SS44-gold.txt` نام مرجع/فایل مرتبط.
- خطاهای network: too many redirects, invalid response body, connection failed, connection timed out, HTTP 304 for unconditional request.
- فیلدهای cache/metadata مانند `etag`, `last_modified`, `content_hash`, `source_cache_*.json`, `cache_age_ms`, `pool_from_cache`, `pool_fresh`.
- خطاهای `no feed configured`, `all feeds failed`, `skipped feeds`, `feed too large` در رشته‌های باینری/فیلترها.
- رفتار frontend به صراحت می‌گوید شکست source نباید باعث switch خاموش به source دیگر شود؛ cache قدیمی حفظ می‌شود، اما failure باید قابل مشاهده باشد.

روند بازسازی‌شده (استنباط قوی):
1. source id به source metadata/feed تعریف‌شده در Registry تبدیل می‌شود.
2. درخواست HTTP با محدودیت redirect/timeout/body-size انجام می‌شود.
3. ETag/Last-Modified و content hash برای caching و تشخیص تغییرات استفاده می‌شوند.
4. body به خطوط کانفیگ parse می‌شود.
5. اگر source خطا بدهد، از cache همان source استفاده می‌شود؛ تغییر source خودکار انجام نمی‌شود.

**نام URLهای production feed در EXE به‌صورت URL literal قابل استخراج پیدا نشد.** self-test آدرس `http://127.0.0.1:9/SS44-gold.txt` را دارد که endpoint محلی عمداً unreachable برای تست شکست است؛ این آدرس subscription واقعی نیست. بنابراین 7 URL اصلی از ZIP موجود قابل تعیین قطعی نیستند.

## 3. Parse/normalize configs

پروتکل‌هایی که برای parsing evidence دارند:
- `vless://`
- `vmess://` (Base64 JSON)
- `trojan://`
- `ss://` (با caveat در cipher/plugin handling)

پارامترهای حمل‌ونقل و امنیتی که نامشان داخل binary آمده:
- Reality/TLS و `xtls-rprx-vision`
- `tcpSettings`, `wsSettings`, `grpcSettings`, `httpupgradeSettings`, `xhttpSettings`
- `multiMode`, `maxEarlyData`, `earlyDataHeaderName`
- Reality public key (`pbk`), short ID (`sid`), SNI, fingerprint/`fp`, flow, host/header, port, UUID/credential.

اعتبارسنجی‌های مشاهده‌شده:
- address/hostname و port معتبر؛ port صفر رد می‌شود.
- VMess Base64/JSON, UUID, cipher, alterId/security validation.
- Reality نیازمند SNI و public key؛ flow بررسی می‌شود.
- `allowInsecure` و خاموش‌کردن verify TLS پذیرفته نمی‌شود.
- Shadowsocks plugin و cipherهای پشتیبانی‌نشده ممکن است رد شوند.
- `mKCP` به‌عنوان transport حذف‌شده در Xray 26 در مسیر خطا دیده می‌شود.
- `hysteria://`, `hysteria2://`, `tuic://`, `httpupgrade://` به‌عنوان scheme unsupported دیده می‌شوند؛ پشتیبانی آن‌ها تأیید نشده است.

خطوط malformed و محتوای غیرکانفیگ reject می‌شوند. Self-test strings شامل نمونه‌های معتبر/نامعتبر VLESS، host خراب، port=0، لینک مخرب و `not-a-config` هستند.

## 4. Pool deduplication and quality pipeline

رشته‌ها شمارنده‌های زیر را نشان می‌دهند:
- `lines`, `valid`, `duplicates`, `unsupported`, `invalid`
- `parsed`, `tested`, `rows`, `quality`, `perf`, `gate_ok`, `countries`
- `ping`, `quality`, `tcp_rejected`, `start_failed`, `ready_failed`, `probe_rounds_ok`, `probe_failed`
- زمان‌های مرحله‌ای `fetch`, `ping`, `quality`, `perf`, `total`.

روند محتمل:
1. Feed lines → normalize/parser.
2. حذف duplicateها.
3. تشخیص protocol/transport/security/country.
4. انتخاب یک quality window از جدیدترین candidateها (پیام binary: `newest ... of ... parsed candidate(s)`).
5. Stage 2 ping; Stage 3 quality; Stage 3b performance; Stage 4 final selection.
6. phaseهای مصرف‌شده توسط UI دقیقاً `fetch`, `ping`, `quality`, `perf`, `geo`, `ready` هستند؛ پیشرفت با `done`/`total` می‌آید و در پایان `pool` فرستاده می‌شود.

Self-test stringها می‌گویند 20 کانفیگ متنوع از نظر host برای تست/انتخاب نمونه انتخاب شود؛ این عدد به معنی limit کل pool نهایی نیست مگر در سورس تایید شود.

## 5. Ping/test/automatic ranking

- `ping_server({key})` تست منفرد؛ event `ping_result` نتیجه `{key, latency_ms, ok}` را می‌فرستد.
- `ping_all()` batch را شروع می‌کند و `ping_result`های متعدد و سپس `ping_all_done` را منتشر می‌کند.
- `measure_delay()` یک delay scalar برمی‌گرداند.
- auto selection یک `auto_rank` و درصد پیشرفت می‌فرستد.
- پیام‌ها از `auto connect picks best first`, `dead/slow/fast`, rank budget و expiry/fallback به partial result حمایت می‌کنند.

### Source/pool state fields observed in serialization strings

در رشته‌های serialization علاوه بر فیلدهای UI، این نام‌ها دیده شده‌اند: `pool_source`, `pool_fetched_at_ms`, `pool_parsed`, `pool_tested`, `pool_countries`, `pool_from_cache`, `cache_age_ms`, `pool_cache_state`, `pool_fresh`, `supported_schemes`, `xray_ready`, `xray_version`, `refreshing`, `checked`, `provider`, `latency_ms`. نام‌ها evidence هستند، اما تعلق دقیق هر فیلد به struct/response خاص بدون سورس قطعی نیست.

## 6. Xray config and process lifecycle

شواهد مستقیم:
- Xray به‌عنوان child process اجرا می‌شود؛ portهای SOCKS، HTTP و API به صورت local/runtime ساخته یا اختصاص داده می‌شوند.
- API محلی stats از `statsquery` پاسخ می‌دهد؛ parser انتظار `stat[]` دارد.
- counter names: `statsUserDownlink`, `statsInboundUplink`, `statsInboundDownlink`.
- generated config sections: `inbounds`, `outbounds`, `routing`, `rules`, `stats`.
- guardها برای وجود HTTP inbound/routing، TUN inbound/routing، port match، stats app و outbound در binary هستند.
- خطاها: version timeout, cannot run/start, stats API timeout, port conflict, exits unexpectedly.
- پیام `xray started socks=... http=... api=... cfg=...` در binary هست.
- Windows process tree با Job Object مدیریت می‌شود (import/use strings مربوط).

برای Android باید به جای process `.exe`، Xray build سازگار با ABI/Android یا هسته سازگار دیگری استفاده شود؛ Windows executable در Android قابل اجرا نیست.

## 7. Tunnel / proxy / DNS

Windows paths:
- TUN با adapter `bepar-tun` و Wintun 0.14.1؛ دسترسی admin/UAC لازم.
- System proxy از registry اعمال و قبل از اتصال snapshot/backup می‌شود؛ فایل `sysproxy-backup.json` در رشته‌ها وجود دارد.
- `proxy_fail_closed` و پیام‌های leak protection نشان می‌دهند اگر تونل ناگهان قطع شود، سعی می‌شود ترافیک سیستم از مسیر پراکسی مرده خارج نشود.
- TUN preflight خطاهای driver/admin را گزارش می‌کند.

DNS provider options:
- system, Cloudflare, Google, Quad9, custom.
- DoH IP endpoints در `observed-endpoints.json` ثبت شده‌اند.
- custom resolver در frontend پذیرش IP یا URL HTTPS را دارد.

## 8. Traffic verification and IP info

پیام‌های binary می‌گویند موفقیت صرف ping کافی نیست؛ اتصال باید از یک real traffic gate عبور کند. شواهد include upload, download, secondary HTTP 204 و ipify. Endpointهای exact در `observed-endpoints.json` هستند.

خروجی IP از `api.ipify.org?format=json`; کشور از `api.country.is` یا `ip-api.com` قابل استنباط است. Cloudflare speed endpoint برای upload/download استفاده می‌شود. نتیجه failed gate ممکن است اتصال را ناموفق کند و auto failover را فعال کند.

## 9. Failover / retry

- `tried`, `server_unavailable`, `xray_unavailable`, `reconnecting`, `active server is unusable; automatic failover` شواهدند.
- failure اتصال یا traffic verification باعث رفتن به candidate بعدی می‌شود.
- محدودیت failover وجود دارد؛ مقدار عددی از رشته‌ها به طور قطعی recover نشد.
- پس از عبور از limit، disconnect با پیام صادقانه انجام می‌شود؛ failover loop بی‌نهایت مجاز نیست.
- لغو اتصال هنگام شروع/درحال اتصال و cleanup probe resources در selftest stringها دیده شده‌اند.
