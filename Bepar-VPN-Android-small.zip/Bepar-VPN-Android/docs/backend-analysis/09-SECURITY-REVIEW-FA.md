# مدل امنیت و رمزنگاری که از Backend قابل مشاهده است

## 1. Encryption-at-rest / connection data

شواهد:
- ماژول‌های `src/crypto.rs` و `src/security.rs`.
- `connection-key.bin`، `bepar-encryption-self-check-v1`، `bepar-vpn-cache-v1`.
- پیام‌ها: `not an encrypted file`, `truncated encrypted file`, `cannot decrypt`, `decryption failed`, `encryption failed`, `secure random unavailable`, `cannot store connection key`.
- متن صریح: خاموش‌کردن connection-data encryption ممنوع/نادیده گرفته می‌شود (`refusing to disable...` و `encrypt_data=false ignored...`).
- Import `CryptProtectData` / `CryptUnprotectData` و DPAPI errors.

نتیجه:
- رمزنگاری داده‌های حساس در cache/config اجباری است.
- نگهداری key به Windows DPAPI متصل است؛ در Android باید Keystore-based key wrapping و الگوریتم/format سازگار جدید طراحی شود.
- `ring 0.17.14` در crate references موجود است، اما این به‌تنهایی ثابت نمی‌کند الگوریتم نهایی فایل دقیقاً AES-GCM یا ChaCha20-Poly1305 بوده. نسخه format/nonce/tag layout از binary strings به طور کامل روشن نشد.

## 2. Integrity baseline

رشته‌ها:
- `integrity.json`, `IntegrityBaseline`, `IntegrityStore`, `update_stamp`, `Bepar.update.stamp`.
- `integrity store MAC mismatch - discarding a forged/rebuilt baseline`.
- `cannot compute integrity store MAC`, `cannot persist integrity state`.
- `Executable integrity check failed`, `running_sha256_prefix`, `stored_sha256_prefix`, `unsigned_or_invalid`.

وجود MAC و baseline برای تشخیص دستکاری evidence دارد. کلید/ساختار دقیق MAC و bootstrap logic از رشته‌ها قابل بازیابی قطعی نیست.

## 3. Anti-debug / security lock

- Windows imports: `IsDebuggerPresent`, `CheckRemoteDebuggerPresent`.
- `debugger attached to the Bepar process`.
- `security_lock` / `security_lock_cleared`; UI در security lock disconnected state و fullscreen lock overlay را نشان می‌دهد.
- startup_check و security_recheck برای preflight/recheck وجود دارند.

## 4. TLS interception / proxy tooling detection

- پیام دقیق: TLS certificate validation failed on two independent hosts while plain HTTP worked → `Active TLS interception detected`.
- Hosts observed nearby include `www.gstatic.com` and `api.github.com`; static dump joins these two; exact probe sequence still not visible.
- Registry installed-app detection + running process check for known interception tools: HTTP Debugger, Fiddler Classic/Everywhere, Charles, mitmproxy, Burp Suite.
- متن UI/source comments می‌گوید نام برنامه به‌تنهایی کافی نیست: live process یا installed registry evidence لازم است.

## 5. Leak protection / fail-closed

- `leak_protection`, `proxy_fail_closed`, `no_management_api`, `no_update_channel` strings.
- اگر proxy/tunnel management به وضعیت امن نرسد، پیام `leak protection could not fail closed` ظاهر می‌شود.
- رفتار مورد انتظار: به جای ادعای محافظت، خطا گزارش شود و از مسیر leak جلوگیری شود.
- جزئیات route/registry transaction ویندوز از متن stringها کامل بازسازی نشده؛ importها و فایل backup به ثبت state کمک می‌کنند.

## 6. Log redaction and clipboard

- logger module و marker `[redacted-config]`.
- کلمات حساس برای redaction شامل `password`, `passwd`, `secret`, `token`, `auth`, `private_key`.
- Secure Clipboard UI-side: اگر برنامه متنی را کپی کند و محتوای clipboard تا 30 ثانیه عوض نشود، همان متن پاک می‌شود. این رفتار در JS قابل مشاهده است.

## 7. Security limitations

این تحلیل audit امنیتی مستقل نیست؛ exploit/penetration test اجرا نشده. رشته‌ها design intent را نشان می‌دهند نه اثبات مؤثر بودن همه کنترل‌ها. به‌خصوص رمزنگاری، integrity MAC، update signing و DPAPI format بدون سورس/PDB/runtime نمی‌تواند به پیاده‌سازی bit-for-bit تبدیل شود.
