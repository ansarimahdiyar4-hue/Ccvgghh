# Inventory آزمون‌های داخلی که نام/پیامشان در باینری دیده شد

این‌ها شواهد string/assertion/test labels از `selftest.rs` هستند؛ در این عملیات، خود برنامه/تست‌های backend اجرا نشده‌اند.

- ساخت directoryهای runtime؛ missing runtime dirs.
- پیش‌فرض source برابر SS44 و انتخاب‌پذیر بودن 7 منبع؛ unknown source باید به default fallback کند؛ source selection نباید silently switch شود.
- JSON خراب settings → defaults؛ settings save/load roundtrip.
- VLESS sample معتبر با TLS و Reality/Vision و نمونه نامعتبر host/port، port=0، malicious lines و `not-a-config`.
- subscription deduplication؛ duplicateها نباید تکرار شوند.
- Xray generated JSON well-formed و وجود بخش‌های مورد انتظار.
- server naming و country resolution از geoip؛ `geoip.dat` missing/unparsable و dataset-too-small checks.
- انتخاب 20 کانفیگ diverse/spread across hosts.
- رتبه‌بندی dead/slow/fast؛ auto connect best first و fallback order.
- Xray binary present/ready؛ free-port allocation و جلوگیری از port 0.
- self-test source با endpoint محلی unreachable و انتظار گزارش خطای clean.
- cleanup probeها و جلوگیری از leak کردن منابع.

`selftest.rs` مسیر test قابل استنباط از binary است. وجود پیام‌های آزمون به معنای پاس شدن آنها در نسخه تحویلی نیست.
