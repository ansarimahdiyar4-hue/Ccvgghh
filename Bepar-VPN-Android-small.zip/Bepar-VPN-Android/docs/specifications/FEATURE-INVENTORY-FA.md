# فهرست فنی Bepar VPN بر اساس رشته‌های داخل فایل اجرایی

> این سند استخراج ایستا از `Bepar VPN.exe` است. وجود یک رشته نشانه‌ای از وجود کد/مسیر/پیام مرتبط است، اما به‌تنهایی اثبات نمی‌کند که هر قابلیت در همه شرایط درست کار می‌کند.

## هویت و پلتفرم
- نام محصول: `Bepar VPN`
- نسخه قابل مشاهده در رشته‌ها: `2.0.0` و شناسه اجرایی `Bepar/2.0.0`
- شناسه بسته دسکتاپ: `com.soheil.kiarsyan.wvpn`
- چارچوب قابل شناسایی: Tauri 2؛ رشته‌های نسخه `tauri-2.12.1` و `tauri-runtime-wry-2.12.1` در فایل وجود دارند.
- WebView2 در پیام‌های اجرایی ذکر شده است.
- فایل اجرایی: Windows PE32+، x86-64؛ فایل Rust native است و برای Android قابل اجرا نیست.

## فرمان‌های frontend-to-backend که در باینری مشاهده شدند
- `connect`
- `disconnect`
- `select_server`
- `ping_server`
- `save_settings`
- `tun_set`

این‌ها نام فرمان‌های IPC هستند؛ سورس UI/JS واقعی نیز جداگانه از assetهای Brotli داخل EXE بازیابی شده و در `07-original-frontend-source` قرار دارد.

## کلیدهای تنظیمات مشاهده‌شده
- `configSource`
- `autoFallback`
- `tunMode`
- `dnsProvider`
- `dnsCustom`
- `leakProtection`
- `acceptTerms`
- `languageChosen`
- `encryptData`
- `logProtection`
- `secureClipboard`

## منبع‌ها و پیکربندی سرورها
- رشته‌های self-test می‌گویند ۷ منبع انتخاب‌پذیر ثبت شده‌اند.
- `SS44-gold.txt` به‌عنوان منبع پیش‌فرض اشاره شده است.
- پیام self-test: `seven selectable config sources registered`.
- توضیحات متنی منبع‌های مشاهده‌شده:
  - Source 1: سازگار با Irancell و Rightel.
  - Source 2: سازگار با Irancell.
  - Source 3: سازگار با Irancell و Hamrah-e Aval.
  - Source 4: سازگار با Irancell، Hamrah-e Aval و اینترنت ثابت.
  - یک دسته روزانه: کانفیگ‌های crawler شده و ping-tested.
  - یک دسته ایران‌محور: عمدتاً REALITY/Vision.
  - یک دسته عمومی: کانفیگ‌های عمومی تأییدشده با Base64.
- نام‌هایی که به‌صورت رشته در ناحیه منابع دیده شدند: `Leon406`, `Morpheus`, `Adam Iran`, `0xRadikal`, `Mahsa`, `Anonymous`, `Patterniha`, `SS44`. نگاشت قطعی هر نام به شماره Source از رشته‌های تنها قابل اثبات نیست.
- رشته‌های self-test می‌گویند انتخاب خودکار باید دقیقاً ۲۰ کانفیگ متنوع از نظر host انتخاب کند.
- به کش منبع‌ها، حذف تکراری‌ها، شمارش خطوط نامعتبر/تکراری/پشتیبانی‌نشده و بازیابی از کش اشاره شده است.

## پروتکل‌ها و پارسرها
- URIهای نمونه و مسیر پارسر برای `vless://`، `vmess://`، `trojan://` و `ss://` وجود دارند.
- تنظیمات parser شامل `realitySettings`، `wsSettings`، `grpcSettings`، `httpupgrade`، `multiMode`، `maxEarlyData` و `earlyDataHeaderName` در رشته‌ها دیده می‌شوند.
- `REALITY` و flow برابر `xtls-rprx-vision` در نمونه آزمایشی وجود دارند.
- `hysteria2://`، `hysteria://`، `tuic://` و `httpupgrade` در یک متن خطای `unsupported scheme` دیده می‌شوند؛ این مورد به‌معنای پشتیبانی از آن‌ها نیست.
- رشته‌های خطا شامل بررسی اعتبار credential، address، port، SNI، public key و JSON/Base64 است.

## اتصال، انتخاب خودکار و failover
- وضعیت‌های متنی شامل `disconnected`, `reconnecting`, `connected via`, `connection attempt already running`, `servers_still_loading`, `select_server_first` هستند.
- مسیرهای خودکار: رده‌بندی pool، ping/quality test، انتخاب نامزدها، تست سرعت/traffic gate، اتصال به سرور بعدی در صورت شکست، سقف failover و بازگشت به حالت قطع.
- پیام‌ها مشخص می‌کنند که پس از چند شکست متوالی traffic check عملیات متوقف می‌شود، به‌جای اینکه کورکورانه همه سرورها را امتحان کند.
- آمار session شامل download/upload bytes و monitor رابط تونل در رشته‌ها دیده می‌شود.

## تست کیفیت و ترافیک
- عبارت‌های `ping-only fallback`, `live-quality`, `traffic-verified`, `untested fallback` در باینری وجود دارند.
- تست‌های ترافیک به endpointهای Cloudflare و Google و ipify اشاره می‌کنند.
- کشور/IP خروجی از `api.country.is` یا `ip-api.com` جست‌وجو می‌شود.
- endpointهای تست سرعت شامل Cloudflare upload/download هستند.
- این رشته‌ها فقط endpoint/منطق مورد انتظار را نشان می‌دهند؛ در این استخراج هیچ تست زنده‌ای اجرا نشده است.

## VPN/TUN/Proxy در نسخه ویندوز
- TUN mode، Wintun، ساخت adapter به نام `bepar-tun` و نیاز به دسترسی elevated/UAC در پیام‌ها دیده می‌شود.
- در نبود Wintun یا مجوز Administrator، خطاهای driver/admin rights گزارش می‌شوند.
- system proxy و تنظیم/بازگردانی آن نیز در نام فایل‌ها و پیام‌های اجرایی آمده است.
- این کدها نسخه ویندوز هستند؛ برای Android باید با `VpnService` و هسته سازگار ARM64/ARMv7 جایگزین شوند.

## DNS و امنیت
- DNS-over-HTTPS endpointهای Cloudflare، Quad9 و Google دیده شدند.
- پیام `encrypt_data=false ignored: connection-data encryption is mandatory` نشان می‌دهد خاموش‌کردن رمزنگاری داده اتصال نادیده گرفته می‌شود.
- رشته‌های `leak protection`, `security lock`, `debugger attached`, `TLS interception`, `executable integrity check` و `secureClipboard` وجود دارند.
- این رشته‌ها نشان‌دهنده مسیرهای امنیتی/خطا هستند، نه ارزیابی مستقل کیفیت امنیتی برنامه.

## فایل‌ها و مسیرهای runtime مشاهده‌شده
- `settings.json`
- `geoip.dat`
- `geosite.dat`
- `integrity.json`
- `test-cache.json`
- `geoip_cache.json`
- `sysproxy-backup.json`
- `connection-key.bin`
- `wvpn.log`
- `test/` و `configs.txt` (در رشته‌های مسیر/runtime)
- `SS44-gold.txt`

## وابستگی‌های ویندوزی و نسخه‌های pin شده در رشته‌ها
- نشانی دانلود Xray: `https://github.com/XTLS/Xray-core/releases/download/v26.3.27/Xray-windows-64.zip`
- نسخه pin شده Wintun: `0.14.1`
- در باینری hashهای SHA-256 مربوط به آرشیوهای دانلودی ثبت شده‌اند؛ این‌ها hash آرشیوها هستند و لزوماً hash فایل `xray.exe` یا `wintun.dll` نیستند.
- فایل `xray.exe` داخل ZIP از نوع Windows PE x86-64 است و مستقیم روی Android اجرا نمی‌شود.

## محدودیت‌های شواهد
- فایل ورودی ZIP شامل EXE، Xray EXE، دو دیتابیس و LICENSE/NOTICE است.
- فایل‌های HTML/CSS/JS و ۲۵۷ پرچم SVG از streamهای Brotli داخل EXE بازیابی شده‌اند؛ سورس frontend در `07-original-frontend-source` است.
- فایل‌های Figma/Sketch و Lottie/After Effects مستقل در ورودی نبودند؛ انیمیشن‌های شناخته‌شده در CSS و JS قرار دارند.
- سورس Rust اصلی قابل بازیابی از executable به‌صورت پروژه buildable نیست. نام مسیرهای `src\*.rs` و رشته‌های خطا در dump حفظ شده‌اند، اما سورس کد کامل نیستند.
