package com.bepar.vpn

import com.bepar.vpn.i18n.BeparStrings
import com.bepar.vpn.model.BeparLanguage
import com.bepar.vpn.model.SourceDisplayRegistry
import org.junit.Assert.*
import org.junit.Test

class LocalizationCompletenessTest {
    @Test
    fun englishAndPersianHaveIdenticalKeySets() {
        assertTrue(BeparStrings.en.size >= 232)
        assertEquals(BeparStrings.en.size, BeparStrings.fa.size)
        assertEquals(BeparStrings.en.keys, BeparStrings.fa.keys)
    }

    @Test
    fun placeholderInterpolationReplacesTokens() {
        val enCount = BeparStrings.text(BeparLanguage.EN, "server_count", mapOf("n" to 42))
        val faCount = BeparStrings.text(BeparLanguage.FA, "server_count", mapOf("n" to 42))
        assertEquals("42 servers", enCount)
        assertEquals("42 سرور", faCount)
    }

    @Test
    fun sourceMaskingHidesRawUpstreamNames() {
        val maskedEn = SourceDisplayRegistry.maskUpstreamNames("Failed loading MorpheusAdam Iran and SS44", BeparLanguage.EN)
        val maskedFa = SourceDisplayRegistry.maskUpstreamNames("خطا در Mahsa", BeparLanguage.FA)
        assertFalse(maskedEn.contains("MorpheusAdam Iran"))
        assertFalse(maskedEn.contains("SS44"))
        assertFalse(maskedFa.contains("Mahsa"))
    }
}
