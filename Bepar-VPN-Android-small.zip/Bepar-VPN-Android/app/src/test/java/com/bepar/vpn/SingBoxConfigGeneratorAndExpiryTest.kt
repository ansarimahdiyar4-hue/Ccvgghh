package com.bepar.vpn

import com.bepar.vpn.backend.ConfigUriParser
import com.bepar.vpn.backend.ServerTester
import com.bepar.vpn.backend.SingBoxConfigGenerator
import com.bepar.vpn.model.DnsProvider
import com.bepar.vpn.model.ServerItem
import org.junit.Assert.*
import org.junit.Test
import java.util.Base64

class SingBoxConfigGeneratorAndExpiryTest {

    @Test
    fun buildsValidSingBoxConfigsForAllFourSupportedProtocols() {
        val validRealityPbk = "u9K4m2P8vL0qR7sT1wX3yZ5aB7cD9eF1gH3iJ5kL7mM"
        val uris = listOf(
            "vless://11111111-2222-3333-4444-555555555555@198.51.100.10:443?security=reality&sni=example.com&fp=chrome&pbk=$validRealityPbk&sid=01ab&flow=xtls-rprx-vision#DE",
            "vmess://" + Base64.getEncoder().encodeToString(
                """{"v":"2","ps":"NL","add":"198.51.100.11","port":443,"id":"aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee","net":"ws","tls":"tls","sni":"nl.example.com","path":"/ws"}""".toByteArray()
            ),
            "trojan://secretpass@198.51.100.12:443?security=tls&sni=fi.example.com&type=grpc&serviceName=grpcSvc#FI",
            "ss://" + Base64.getUrlEncoder().withoutPadding().encodeToString("aes-256-gcm:sspass".toByteArray()) + "@198.51.100.13:8388#US"
        )

        val parsed = ConfigUriParser.parsePool(uris)
        assertEquals(4, parsed.nodes.size)

        for (node in parsed.nodes) {
            val cfg = SingBoxConfigGenerator.buildConfig(
                node = node,
                mixedPort = 10808,
                dnsProvider = DnsProvider.CLOUDFLARE,
                dnsCustom = "",
                tunMode = true,
                leakProtection = true
            )
            val errors = SingBoxConfigGenerator.validateGeneratedConfig(cfg)
            assertTrue("Expected no errors for ${node.protocol}, got $errors", errors.isEmpty())
            val outbounds = cfg.getJSONArray("outbounds")
            assertEquals("proxy", outbounds.getJSONObject(0).getString("tag"))
            assertEquals("tun", cfg.getJSONArray("inbounds").getJSONObject(0).getString("type"))
        }
    }

    @Test
    fun rejectsPrivateAndLoopbackHostsAndExpiredConfigs() {
        val nowMs = 1_780_000_000_000L
        val loopback = "vless://11111111-2222-3333-4444-555555555555@127.0.0.1:443?security=tls&sni=a.com#Local"
        val rfc1918 = "trojan://secret@192.168.1.10:443?security=tls&sni=b.com#Lan"
        val expiredRemark = "vless://11111111-2222-3333-4444-555555555555@198.51.100.40:443?security=tls&sni=c.com#Node%20expire:2020-01-01"
        val activeNode = "vless://11111111-2222-3333-4444-555555555555@198.51.100.41:443?security=tls&sni=d.com#Node%20expire:2099-01-01"

        val res = ConfigUriParser.parsePool(
            lines = listOf(loopback, rfc1918, expiredRemark, activeNode),
            nowMs = nowMs
        )
        assertEquals(1, res.nodes.size)
        assertEquals(2, res.stats.invalid)
        assertEquals(1, res.stats.expired)

        val expiredHeader = ConfigUriParser.parseSubscriptionUserinfoExpireMs("upload=0; download=0; total=1000; expire=1577836800")
        assertNotNull(expiredHeader)
        val subExpiredRes = ConfigUriParser.parsePool(listOf(activeNode), nowMs = nowMs, subscriptionExpireMs = expiredHeader)
        assertEquals(0, subExpiredRes.nodes.size)
        assertEquals(1, subExpiredRes.stats.expired)
    }

    @Test
    fun autoRankServersPrioritizesReachableLowLatencyAndFiltersExpired() {
        val nowMs = 1_780_000_000_000L
        val servers = listOf(
            ServerItem("dead", "DE 1", "de", latencyMs = 20, reachable = false, stability = 1.0),
            ServerItem("exp", "NL 1", "nl", latencyMs = 10, reachable = true, stability = 1.0, expiresAtMs = nowMs - 1000L),
            ServerItem("slow", "US 1", "us", latencyMs = 310, reachable = true, stability = 0.5, security = "tls"),
            ServerItem("fast", "FI 1", "fi", latencyMs = 75, reachable = true, stability = 0.9, security = "reality")
        )
        val ranked = ServerTester.autoRankServers(servers, nowMs = nowMs)
        assertEquals(listOf("fast", "slow", "dead"), ranked.map { it.key })
    }
}
