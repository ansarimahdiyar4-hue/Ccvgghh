package com.bepar.vpn

import com.bepar.vpn.model.BootGate
import com.bepar.vpn.model.InMemoryTestBackendGateway
import com.bepar.vpn.model.SettingsSubScreen
import com.bepar.vpn.security.DevPinSecurity
import com.bepar.vpn.state.BeparViewModel
import com.bepar.vpn.state.DevPinDialogMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class DevPinAndConsumerPrivacyTest {
    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun pbkdf2PinHashingAndVerificationWorkReliably() {
        val salt = DevPinSecurity.generateSaltHex()
        val hash = DevPinSecurity.hashPin("4829", salt)
        assertTrue(DevPinSecurity.verifyPin("4829", salt, hash))
        assertFalse(DevPinSecurity.verifyPin("4820", salt, hash))
        assertFalse(DevPinSecurity.verifyPin("123", salt, hash))
        assertFalse(DevPinSecurity.verifyPin("4829", "", hash))
    }

    @Test
    fun sevenTapLogoGestureRequiresPinCreationThenUnlock() = runTest {
        val vm = BeparViewModel(InMemoryTestBackendGateway())
        advanceUntilIdle()
        assertFalse(vm.uiState.value.devModeUnlocked)
        assertEquals(DevPinDialogMode.NONE, vm.uiState.value.devPinDialogMode)

        // Normal consumer taps < 7 do not unlock Developer Mode
        repeat(6) { vm.onLogoTapped() }
        assertEquals(DevPinDialogMode.NONE, vm.uiState.value.devPinDialogMode)
        assertFalse(vm.uiState.value.devModeUnlocked)

        // 7th tap opens CREATE_PIN dialog when no PIN has been set yet
        vm.onLogoTapped()
        assertEquals(DevPinDialogMode.CREATE_PIN, vm.uiState.value.devPinDialogMode)

        // Mismatched PIN fails gracefully
        vm.submitNewDevPin("7391", "7390")
        assertFalse(vm.uiState.value.devModeUnlocked)
        assertNotNull(vm.uiState.value.devPinError)

        // Valid matching PIN unlocks Developer Mode and navigates to SettingsSubScreen.DEVELOPER
        vm.submitNewDevPin("7391", "7391")
        assertTrue(vm.uiState.value.devModeUnlocked)
        assertTrue(vm.uiState.value.devPinConfigured)
        assertEquals(SettingsSubScreen.DEVELOPER, vm.uiState.value.settingsSubScreen)

        // Locking hides Developer Mode and subsequent 7 taps require VERIFY_PIN
        vm.lockDeveloperMode()
        assertFalse(vm.uiState.value.devModeUnlocked)
        assertEquals(SettingsSubScreen.NONE, vm.uiState.value.settingsSubScreen)

        repeat(7) { vm.onLogoTapped() }
        assertEquals(DevPinDialogMode.VERIFY_PIN, vm.uiState.value.devPinDialogMode)

        vm.verifyDevPin("0000")
        assertFalse(vm.uiState.value.devModeUnlocked)
        assertNotNull(vm.uiState.value.devPinError)

        vm.verifyDevPin("7391")
        assertTrue(vm.uiState.value.devModeUnlocked)
        assertEquals(SettingsSubScreen.DEVELOPER, vm.uiState.value.settingsSubScreen)
    }

    @Test
    fun consumerPowerPressWithEmptyServersDoesNotOpenRawImportDrawer() = runTest {
        val vm = BeparViewModel(InMemoryTestBackendGateway())
        advanceUntilIdle()
        vm.onPowerPressed()
        advanceUntilIdle()
        assertFalse(vm.uiState.value.importDrawerOpen)
    }
}
