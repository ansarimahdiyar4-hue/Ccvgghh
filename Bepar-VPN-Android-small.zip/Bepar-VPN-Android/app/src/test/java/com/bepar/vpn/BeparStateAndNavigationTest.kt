package com.bepar.vpn

import com.bepar.vpn.model.*
import com.bepar.vpn.state.BeparViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class BeparStateAndNavigationTest {
    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun bootOrderFollowsLanguageTermsOnboardingHome() = runTest {
        val vm = BeparViewModel(InMemoryTestBackendGateway())
        assertEquals(BootGate.SPLASH, vm.uiState.value.bootGate)
        advanceUntilIdle()
        assertEquals(BootGate.LANGUAGE, vm.uiState.value.bootGate)

        vm.chooseInitialLanguage(BeparLanguage.FA)
        assertEquals(BootGate.TERMS, vm.uiState.value.bootGate)
        assertEquals(BeparLanguage.FA, vm.uiState.value.language)

        // Cannot accept terms before checking box
        vm.acceptTerms()
        assertEquals(BootGate.TERMS, vm.uiState.value.bootGate)

        vm.setTermsChecked(true)
        vm.acceptTerms()
        assertEquals(BootGate.ONBOARDING, vm.uiState.value.bootGate)

        vm.pickOnboardingSource("mahsa")
        vm.continueOnboardingToMode()
        assertEquals(OnboardingStep.MODE, vm.uiState.value.onboardingStep)

        vm.pickOnboardingMode(ConnectionMode.MANUAL)
        vm.completeOnboarding()
        assertEquals(BootGate.READY, vm.uiState.value.bootGate)
        assertTrue(vm.uiState.value.onboarded)
        assertEquals("mahsa", vm.uiState.value.configSourceId)
        assertEquals("", vm.uiState.value.selectedServer.key)
    }

    @Test
    fun navigationAndSubScreensWorkCorrectly() = runTest {
        val vm = BeparViewModel(InMemoryTestBackendGateway())
        advanceUntilIdle()
        vm.chooseInitialLanguage(BeparLanguage.EN)
        vm.setTermsChecked(true)
        vm.acceptTerms()
        vm.completeOnboarding()

        vm.openSubScreen(SettingsSubScreen.DNS)
        assertEquals(AppPage.SETTINGS, vm.uiState.value.page)
        assertEquals(SettingsSubScreen.DNS, vm.uiState.value.settingsSubScreen)

        vm.closeSubScreen()
        assertEquals(SettingsSubScreen.NONE, vm.uiState.value.settingsSubScreen)

        vm.navigateTo(AppPage.ABOUT)
        assertEquals(AppPage.ABOUT, vm.uiState.value.page)
    }

    @Test
    fun missingNativeLibrariesFailClosedWithoutFakeConnection() = runTest {
        val vm = BeparViewModel(InMemoryTestBackendGateway())
        advanceUntilIdle()
        vm.onPowerPressed()
        advanceUntilIdle()
        assertEquals(ConnectionState.DISCONNECTED, vm.uiState.value.status.state)
        assertFalse(vm.uiState.value.status.isLiveEngine)
        assertNotNull(vm.uiState.value.snackbarMessage)
    }

    @Test
    fun naturalServerSortingGroupsCountriesAndNumbers() {
        val list = listOf(
            ServerItem("k10", "Germany 10", "de", "Germany", "آلمان", null, "1.1.1.1"),
            ServerItem("k2", "Germany 2", "de", "Germany", "آلمان", null, "1.1.1.2"),
            ServerItem("k1", "Finland 1", "fi", "Finland", "فنلاند", null, "1.1.1.3"),
            ServerItem("kx", "Unknown 1", "", "", "", null, "1.1.1.4")
        )
        val sorted = BeparViewModel.sortAndFilterServers(list, "")
        assertEquals(listOf("k1", "k2", "k10", "kx"), sorted.map { it.key })

        val filtered = BeparViewModel.sortAndFilterServers(list, "فنلاند")
        assertEquals(listOf("k1"), filtered.map { it.key })
    }

    @Test
    fun settingsPersistenceHydratesOnReboot() = runTest {
        val store = object : com.bepar.vpn.security.BeparSettingsPersistence {
            private var saved = com.bepar.vpn.security.PersistedBeparSettings()
            override fun load() = saved
            override fun save(settings: com.bepar.vpn.security.PersistedBeparSettings) {
                saved = settings
            }
        }
        val vm1 = BeparViewModel(InMemoryTestBackendGateway(), settingsStore = store)
        advanceUntilIdle()
        vm1.chooseInitialLanguage(BeparLanguage.FA)
        vm1.setTermsChecked(true)
        vm1.acceptTerms()
        vm1.pickOnboardingSource("morpheus")
        vm1.completeOnboarding()
        vm1.setThemeMode(BeparThemeMode.LIGHT)
        vm1.setReducedMotion(true)

        val vm2 = BeparViewModel(InMemoryTestBackendGateway(), settingsStore = store)
        advanceUntilIdle()
        assertEquals(BootGate.READY, vm2.uiState.value.bootGate)
        assertEquals(BeparLanguage.FA, vm2.uiState.value.language)
        assertEquals(BeparThemeMode.LIGHT, vm2.uiState.value.theme)
        assertEquals("morpheus", vm2.uiState.value.configSourceId)
        assertTrue(vm2.uiState.value.reducedMotion)
    }
}
