================================================================================
libbox.aar — هستهٔ native تونل (sing-box)
================================================================================

وضعیت این بسته: فایل libbox.aar نسخهٔ 1.14.0 داخل همین پوشه قرار دارد.

منبع:
  https://github.com/singbox-android/libbox/releases/tag/1.14.0
  (SDK رسمی sing-box برای اندروید، package: io.nekohasekai.libbox)

محتوا:
  - classes.jar (API جاوا/کاتلین)
  - jni/armeabi-v7a/libbox.so
  - jni/arm64-v8a/libbox.so
  - jni/x86/libbox.so
  - jni/x86_64/libbox.so

با این فایل، پروژه باید کامپایل شود و تونل واقعی از طریق BeparVpnService
قابل راه‌اندازی باشد (پس از دادن مجوز VPN سیستم).

در صورت نیاز به نسخهٔ جدیدتر:
  https://github.com/singbox-android/libbox/releases
  فایل libbox.aar را جایگزین کنید و در صورت تغییر API، کد را تطبیق دهید.
